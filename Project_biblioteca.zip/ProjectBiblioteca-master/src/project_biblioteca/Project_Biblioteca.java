
package project_biblioteca;

import java.sql.*;

//
// Autor: Javier Simón Perea
//

public class Project_Biblioteca {

    public static void main(String[] args) {
        
        /*LOG*/ System.out.println("PROGRAM INITIATED");
        
        Login inicio = new Login();

        
        
    }    
    

    
}

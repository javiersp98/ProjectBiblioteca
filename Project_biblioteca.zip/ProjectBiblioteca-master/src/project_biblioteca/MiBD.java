/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project_biblioteca;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author jcbs
 */
public class MiBD {

    public static Connection conn = null;
    
    public void connect() throws ClassNotFoundException, SQLException {
        
        String sDriver = "com.mysql.jdbc.Driver";
        String sURL = "jdbc:mysql://localhost:3306/library?useSSL=false";        
        
        try {
            try {
                Class.forName(sDriver).newInstance();
            } catch (ClassNotFoundException ex) {
                /*LOG*/System.out.println("ERROR Driver not found");
            }
        } catch (InstantiationException ex) {
            /*LOG*/System.out.println("ERROR Instantiation");
        } catch (IllegalAccessException ex) {
            /*LOG*/System.out.println("ERROR Access to database is not autorized");
        }        
        
        try {            
            conn = DriverManager.getConnection(sURL, "root", "");
            /*LOG*/System.out.println("Connected to database");
        } catch (SQLException ex) {
            /*LOG*/System.out.println("ERROR DriverManager");
        }
        
    }    
    
}
